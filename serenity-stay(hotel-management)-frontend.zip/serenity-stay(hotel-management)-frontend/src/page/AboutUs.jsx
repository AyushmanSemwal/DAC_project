const AboutUs = () => {
  return (
    <div className="text-color ms-5 me-5 mr-5 mt-3">
      <b>
        The project, Serenity Stay is a web-based application that 
        allows the hotel manager to handle all hotel activities online. 
        Interactive GUI and the ability to manage various hotel bookings and 
        rooms make this system very flexible and convenient. The hotel manager 
        is a very busy person and does not have the time to sit and manage 
        the entire activities manually on paper. This application gives him 
        the power and flexibility to manage the entire system from a single 
        online system. Hotel management project provides room booking, staff 
        management and other necessary hotel management features. The system 
        allows the manager to post available rooms in the system. 
        Customers can view and book room online. Admin has the power of either 
        approving or disapproving the customer’s booking request. Other hotel 
        services can also be viewed by the customers and can book them too. 
        The system is hence useful for both customers and managers to portable 
        manage the hotel activities.

        <br />
        <br />
        The project, Serenity Stay is a web-based application that 
        allows the hotel manager to handle all hotel activities online. 
        Interactive GUI and the ability to manage various hotel bookings and 
        rooms make this system very flexible and convenient. The hotel manager 
        is a very busy person and does not have the time to sit and manage 
        the entire activities manually on paper. This application gives him 
        the power and flexibility to manage the entire system from a single 
        online system. Hotel management project provides room booking, staff 
        management and other necessary hotel management features. The system 
        allows the manager to post available rooms in the system. 
        Customers can view and book room online. Admin has the power of either 
        approving or disapproving the customer’s booking request. Other hotel 
        services can also be viewed by the customers and can book them too. 
        The system is hence useful for both customers and managers to portable 
        manage the hotel activities.
      </b>
    </div>
  );
};

export default AboutUs;
